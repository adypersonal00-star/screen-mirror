package com.zapia.screenmirror

import android.Manifest
import android.accessibilityservice.AccessibilityServiceInfo
import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.accessibility.AccessibilityManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

class MainActivity : ComponentActivity() {
    private val refresh = mutableIntStateOf(0)
    private val cameraPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { refresh.intValue++ }
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); setContent { ScreenMirrorUI(refresh.intValue) } }
    override fun onResume() { super.onResume(); refresh.intValue++ }
    private fun begin() {
        if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) { cameraPermission.launch(Manifest.permission.CAMERA); return }
        if (!accessibilityEnabled()) { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)); return }
        val i = Intent(this, MirrorForegroundService::class.java).setAction(MirrorForegroundService.START)
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
        sendBroadcast(Intent(ScreenMirrorAccessibilityService.ACTION_SHOW).setPackage(packageName))
    }
    @Composable private fun ScreenMirrorUI(tick:Int) {
        val cam = checkSelfPermission(Manifest.permission.CAMERA)==PackageManager.PERMISSION_GRANTED
        val a11y = accessibilityEnabled()
        MaterialTheme(colorScheme=darkColorScheme(primary=Color(0xFF8FE2B0),background=Color(0xFF080A0D),surface=Color(0xFF141A20))) {
            Column(Modifier.fillMaxSize().background(Color(0xFF080A0D)).verticalScroll(rememberScrollState()).padding(24.dp), verticalArrangement=Arrangement.spacedBy(16.dp)) {
                Text("ESPEJO DE PANTALLA",color=Color(0xFFEAF0F6),fontSize=26.sp,fontWeight=FontWeight.Black)
                Text("Prototipo de asistencia visual",color=Color(0xFFFFCF7A),fontSize=17.sp,fontWeight=FontWeight.Bold)
                Text("Muestra una ventana pequeña de cámara en vivo encima de otras apps. Puedes moverla arrastrándola. Esta primera versión NO detecta todavía los fondos planos ni los reemplaza automáticamente.",color=Color(0xFFEAF0F6),fontSize=16.sp)
                Text("Cámara: ${if(cam)"permitida" else "falta permiso"}\nAccesibilidad: ${if(a11y)"activada" else "desactivada"}",color=Color(0xFF9BFFB5),fontSize=15.sp)
                Button(onClick={if(!cam)cameraPermission.launch(Manifest.permission.CAMERA) else begin()},modifier=Modifier.fillMaxWidth()){Text(if(cam)"Iniciar ventana de cámara" else "Permitir cámara")}
                OutlinedButton(onClick={startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))},modifier=Modifier.fillMaxWidth()){Text("Activar servicio de Accesibilidad")}
                OutlinedButton(onClick={sendBroadcast(Intent(ScreenMirrorAccessibilityService.ACTION_STOP).setPackage(packageName));stopService(Intent(this@MainActivity,MirrorForegroundService::class.java))},modifier=Modifier.fillMaxWidth()){Text("Detener espejo")}
                HorizontalDivider(color=Color.Gray)
                Text("Límites importantes",color=Color(0xFF9BFFB5),fontWeight=FontWeight.Bold)
                Text("Android no permite a una app recolorear de forma universal la interfaz de otras apps. Textos, iconos y controles no siempre están expuestos por Accesibilidad; los degradados y fondos complejos no se pueden separar de forma fiable. Capturar la pantalla para analizarla requiere consentimiento de Android en cada sesión. Esta versión no toma capturas ni envía video a internet.",color=Color(0xFFBAC4CD),fontSize=14.sp)
            }
        }
    }
    private fun accessibilityEnabled():Boolean {
        val m=getSystemService(ACCESSIBILITY_SERVICE) as AccessibilityManager
        val target=ComponentName(this,ScreenMirrorAccessibilityService::class.java)
        return m.getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_ALL_MASK).any { it.resolveInfo.serviceInfo.packageName==packageName && it.resolveInfo.serviceInfo.name==target.className }
    }
}
