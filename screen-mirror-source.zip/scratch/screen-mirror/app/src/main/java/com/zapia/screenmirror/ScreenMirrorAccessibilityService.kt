package com.zapia.screenmirror

import android.accessibilityservice.AccessibilityService
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import android.graphics.SurfaceTexture
import android.hardware.camera2.CameraCaptureSession
import android.hardware.camera2.CameraDevice
import android.hardware.camera2.CameraManager
import android.hardware.camera2.CaptureRequest
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.view.Gravity
import android.view.MotionEvent
import android.view.TextureView
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.FrameLayout
import android.widget.TextView

class ScreenMirrorAccessibilityService : AccessibilityService() {
    private var box: View?=null
    private var camera: CameraDevice?=null
    private var session: CameraCaptureSession?=null
    private var thread:HandlerThread?=null
    private var handler:Handler?=null
    private var texture:TextureView?=null
    private val receiver=object:BroadcastReceiver(){override fun onReceive(context:Context?,intent:Intent?){when(intent?.action){ACTION_SHOW->show();ACTION_STOP->hide()}}}
    override fun onServiceConnected(){super.onServiceConnected();val f=IntentFilter().apply{addAction(ACTION_SHOW);addAction(ACTION_STOP)};if(Build.VERSION.SDK_INT>=33)registerReceiver(receiver,f,Context.RECEIVER_NOT_EXPORTED)else @Suppress("DEPRECATION") registerReceiver(receiver,f)}
    override fun onAccessibilityEvent(event:AccessibilityEvent?) {}
    override fun onInterrupt(){}
    override fun onDestroy(){runCatching{unregisterReceiver(receiver)};hide();super.onDestroy()}
    private fun show(){if(box!=null)return
        val wm=getSystemService(WINDOW_SERVICE) as WindowManager
        val preview=TextureView(this).apply{surfaceTextureListener=object:TextureView.SurfaceTextureListener{
            override fun onSurfaceTextureAvailable(st:SurfaceTexture,w:Int,h:Int){openCamera(st,w,h)}
            override fun onSurfaceTextureSizeChanged(st:SurfaceTexture,w:Int,h:Int){}
            override fun onSurfaceTextureDestroyed(st:SurfaceTexture):Boolean{closeCamera();return true}
            override fun onSurfaceTextureUpdated(st:SurfaceTexture){}
        }}
        texture=preview
        val root=FrameLayout(this).apply{setBackgroundColor(Color.TRANSPARENT);addView(preview,FrameLayout.LayoutParams(-1,-1));addView(TextView(this@ScreenMirrorAccessibilityService).apply{text="CAM";setTextColor(Color.WHITE);textSize=10f;setBackgroundColor(0x66000000);gravity=Gravity.CENTER},FrameLayout.LayoutParams(42,24,Gravity.TOP or Gravity.END));setOnTouchListener(DragTouch())}
        val type=WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY
        val lp=WindowManager.LayoutParams((resources.displayMetrics.widthPixels*.38).toInt(),(resources.displayMetrics.heightPixels*.25).toInt(),type,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,android.graphics.PixelFormat.TRANSLUCENT).apply{gravity=Gravity.TOP or Gravity.END;x=dp(12);y=dp(130);title="Espejo de cámara"}
        runCatching{wm.addView(root,lp);box=root}.onFailure{box=null;texture=null}
    }
    private fun openCamera(st:SurfaceTexture,w:Int,h:Int){
        if(checkSelfPermission(android.Manifest.permission.CAMERA)!=android.content.pm.PackageManager.PERMISSION_GRANTED)return
        val t=HandlerThread("MirrorCamera").also{it.start()};thread=t;handler=Handler(t.looper)
        try {
            val mgr=getSystemService(Context.CAMERA_SERVICE) as CameraManager
            val id=mgr.cameraIdList.firstOrNull{mgr.getCameraCharacteristics(it).get(android.hardware.camera2.CameraCharacteristics.LENS_FACING)==android.hardware.camera2.CameraCharacteristics.LENS_FACING_BACK}?:mgr.cameraIdList.firstOrNull()?:return
            st.setDefaultBufferSize(w.coerceAtLeast(320),h.coerceAtLeast(240))
            mgr.openCamera(id,object:CameraDevice.StateCallback(){override fun onOpened(d:CameraDevice){camera=d;val s=android.view.Surface(st);d.createCaptureSession(listOf(s),object:CameraCaptureSession.StateCallback(){override fun onConfigured(cs:CameraCaptureSession){session=cs;val request=d.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW).apply{addTarget(s);set(CaptureRequest.CONTROL_MODE,CaptureRequest.CONTROL_MODE_AUTO)}.build();cs.setRepeatingRequest(request,null,handler)};override fun onConfigureFailed(cs:CameraCaptureSession){}},handler)};override fun onDisconnected(d:CameraDevice){d.close();camera=null};override fun onError(d:CameraDevice,error:Int){d.close();camera=null}},handler)
        }catch(_:Exception){closeCamera()}
    }
    private fun closeCamera(){runCatching{session?.close()};session=null;runCatching{camera?.close()};camera=null;thread?.quitSafely();thread=null;handler=null}
    private fun hide(){closeCamera();val v=box;box=null;texture=null;if(v!=null)runCatching{(getSystemService(WINDOW_SERVICE) as WindowManager).removeView(v)}}
    private fun dp(v:Int)=(v*resources.displayMetrics.density).toInt()
    private inner class DragTouch:View.OnTouchListener{var sx=0f;var sy=0f;var x0=0;var y0=0;override fun onTouch(v:View,e:MotionEvent):Boolean{val wm=getSystemService(WINDOW_SERVICE) as WindowManager;val lp=box?.layoutParams as? WindowManager.LayoutParams?:return false;when(e.action){MotionEvent.ACTION_DOWN->{sx=e.rawX;sy=e.rawY;x0=lp.x;y0=lp.y;return true};MotionEvent.ACTION_MOVE->{lp.x=x0-(e.rawX-sx).toInt();lp.y=y0+(e.rawY-sy).toInt();runCatching{wm.updateViewLayout(box,lp)};return true}};return true}}
    companion object{const val ACTION_SHOW="com.zapia.screenmirror.SHOW";const val ACTION_STOP="com.zapia.screenmirror.HIDE"}
}
