package com.zapia.screenmirror

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.IBinder

class MirrorForegroundService : Service() {
    override fun onCreate() { super.onCreate(); if(Build.VERSION.SDK_INT>=26){ val mgr=getSystemService(NotificationManager::class.java);mgr.createNotificationChannel(NotificationChannel(CHANNEL,getString(R.string.channel_name),NotificationManager.IMPORTANCE_LOW).apply{description=getString(R.string.channel_description)}) } }
    override fun onStartCommand(intent:Intent?,flags:Int,startId:Int):Int {
        if(intent?.action==STOP){stopForeground(STOP_FOREGROUND_REMOVE);stopSelf();return START_NOT_STICKY}
        val n:Notification = if(Build.VERSION.SDK_INT>=26) Notification.Builder(this,CHANNEL).setSmallIcon(android.R.drawable.ic_menu_camera).setContentTitle("Espejo de pantalla activo").setContentText("La cámara se muestra en una ventana flotante").setOngoing(true).build() else Notification.Builder(this).setSmallIcon(android.R.drawable.ic_menu_camera).setContentTitle("Espejo de pantalla activo").setOngoing(true).build()
        if(Build.VERSION.SDK_INT>=29) startForeground(ID,n,android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_CAMERA) else startForeground(ID,n)
        return START_NOT_STICKY
    }
    override fun onBind(intent:Intent?):IBinder?=null
    companion object { const val START="com.zapia.screenmirror.START";const val STOP="com.zapia.screenmirror.STOP";private const val CHANNEL="mirror_camera";private const val ID=701 }
}
